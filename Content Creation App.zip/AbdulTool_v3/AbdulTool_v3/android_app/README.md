# Abdul Tool — Android App

## Android Studio mein Open Karo

### Step 1 — Project Open
1. Android Studio kholo
2. "Open an Existing Project" click karo
3. Is folder ko select karo: AbdulTool/android_app/
4. Gradle sync hone do (2-3 minute)

### Step 2 — API URL set karo
File: app/src/main/java/com/abdultool/api/ApiClient.java
```java
public static String BASE_URL = "https://YOUR-RAILWAY-URL.railway.app";
public static final String API_KEY = "abdultool-secret-2024";
```

### Step 3 — Firebase credentials confirm karo
File: app/src/main/java/com/abdultool/utils/FirebaseHelper.java
```java
private static final String API_KEY = "AIzaSyD3-ZBVajRdHmnWjjdsuJDZlNhFrKITB2E";
private static final String DB_URL  = "https://abdul-tool-default-rtdb.firebaseio.com";
```
(Yeh already set hain — same desktop project wali values)

### Step 4 — Build APK
Build → Build Bundle(s) / APK(s) → Build APK(s)
APK milegi: app/build/outputs/apk/debug/app-debug.apk

### Step 5 — Install on Phone
1. Phone mein "Unknown Sources" enable karo
2. APK file phone mein copy karo
3. Install karo

## App Flow
License Screen → Login → Dashboard → Video Tool / Admin Panel

## Screens
- LicenseActivity  — Trial ya key se activate
- LoginActivity    — Firebase email/password login
- DashboardActivity — Main menu (role based)
- VideoToolActivity — Download, Split, Face Filter
- AdminActivity    — Users manage karo (admin only)
