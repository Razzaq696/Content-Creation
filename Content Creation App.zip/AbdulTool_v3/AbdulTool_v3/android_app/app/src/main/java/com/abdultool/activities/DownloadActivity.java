package com.abdultool.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.abdultool.R;
import com.abdultool.api.ApiClient;
import com.abdultool.utils.FileDownloader;
import org.json.JSONObject;

public class DownloadActivity extends AppCompatActivity {

    EditText    etUrl;
    TextView    tvStatus, tvPercent, tvMB, tvSpeed, tvETA, tvFilename, tvSaveInfo;
    Button      btnDownload, btnCancel, btnSaveToPhone;
    ProgressBar progressBar;
    SharedPreferences prefs;

    String currentJobId = null;
    Handler handler = new Handler();
    Runnable pollRunnable;
    boolean isPollRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);

        prefs        = getSharedPreferences("AbdulTool", MODE_PRIVATE);
        etUrl        = findViewById(R.id.etUrl);
        tvStatus     = findViewById(R.id.tvDownloadStatus);
        tvPercent    = findViewById(R.id.tvPercent);
        tvMB         = findViewById(R.id.tvMB);
        tvSpeed      = findViewById(R.id.tvSpeed);
        tvETA        = findViewById(R.id.tvETA);
        tvFilename   = findViewById(R.id.tvFilename);
        tvSaveInfo   = findViewById(R.id.tvSaveInfo);
        btnDownload  = findViewById(R.id.btnDownload);
        btnCancel    = findViewById(R.id.btnCancel);
        btnSaveToPhone = findViewById(R.id.btnSaveToPhone);
        progressBar  = findViewById(R.id.progressBar);

        tvSaveInfo.setText("📁 After download tap 'Save to Phone' to save in\nDownloads/AbdulTool/ folder");
        btnCancel.setEnabled(false);
        btnSaveToPhone.setVisibility(View.GONE);

        btnDownload.setOnClickListener(v -> startDownload());
        btnCancel.setOnClickListener(v -> cancelDownload());
        btnSaveToPhone.setOnClickListener(v -> saveVideoToPhone());
    }

    void startDownload() {
        String url = etUrl.getText().toString().trim();
        if (url.isEmpty()) { toast("Please enter a video URL"); return; }

        setStatus("Starting download...", "#F9A825");
        progressBar.setProgress(0);
        progressBar.setVisibility(View.VISIBLE);
        tvPercent.setText("0%");
        tvMB.setText("Connecting...");
        tvSpeed.setText(""); tvETA.setText(""); tvFilename.setText("");
        btnDownload.setEnabled(false);
        btnCancel.setEnabled(true);
        btnSaveToPhone.setVisibility(View.GONE);

        try {
            JSONObject body = new JSONObject();
            body.put("url", url);
            ApiClient.post("/download", body, new ApiClient.ApiCallback() {
                public void onSuccess(String resp) {
                    try {
                        JSONObject json = new JSONObject(resp);
                        currentJobId = json.getString("job_id");
                        prefs.edit()
                                .putString("last_job_id", currentJobId)
                                .putString("split_job_id", currentJobId)
                                .apply();
                        startPolling();
                    } catch (Exception e) { handleError(e.getMessage()); }
                }
                public void onError(String err) {
                    handleError("Cannot connect to server.\nCheck:\n1. Internet connection\n2. Railway URL in ApiClient.java\n\nError: " + err);
                }
            });
        } catch (Exception e) { handleError(e.getMessage()); }
    }

    void startPolling() {
        isPollRunning = true;
        pollRunnable = new Runnable() {
            public void run() {
                if (!isPollRunning) return;
                ApiClient.get("/job/" + currentJobId, new ApiClient.ApiCallback() {
                    public void onSuccess(String resp) {
                        try {
                            JSONObject j  = new JSONObject(resp);
                            String status = j.optString("status","");
                            double pct    = j.optDouble("percent",0);
                            double dlMb   = j.optDouble("downloaded_mb",0);
                            double totMb  = j.optDouble("total_mb",0);
                            double spd    = j.optDouble("speed_kb",0);
                            int    eta    = j.optInt("eta_sec",0);

                            runOnUiThread(() -> {
                                progressBar.setProgress((int)pct);
                                tvPercent.setText(String.format("%.1f%%", pct));
                                if (totMb > 0)
                                    tvMB.setText(String.format("%.1f MB / %.1f MB", dlMb, totMb));
                                else
                                    tvMB.setText(String.format("%.1f MB downloaded", dlMb));
                                tvSpeed.setText(spd > 1024
                                        ? String.format("%.1f MB/s", spd/1024)
                                        : String.format("%.0f KB/s", spd));
                                tvETA.setText(eta > 0 ? "ETA " + eta + "s" : "");
                                if (status.equals("downloading"))
                                    setStatus("Downloading...", "#F9A825");
                                else if (status.equals("processing"))
                                    setStatus("Processing...", "#F9A825");
                            });

                            if (status.equals("done")) {
                                stopPolling();
                                String fname  = j.optString("filename","video.mp4");
                                double sizeMb = j.optDouble("size_mb",0);
                                prefs.edit().putString("last_filename", fname).apply();
                                runOnUiThread(() -> {
                                    progressBar.setProgress(100);
                                    tvPercent.setText("100%");
                                    tvFilename.setText("✅ " + fname
                                            + " (" + String.format("%.1f",sizeMb) + " MB)");
                                    tvSpeed.setText(""); tvETA.setText("");
                                    setStatus("✅ Download complete on server!\nNow tap 'Save to Phone' to download it.", "#4CAF50");
                                    btnDownload.setEnabled(true);
                                    btnCancel.setEnabled(false);
                                    // Show save button
                                    btnSaveToPhone.setVisibility(View.VISIBLE);
                                    tvSaveInfo.setText("📁 Save location: Downloads/AbdulTool/" + fname);
                                });
                            } else if (status.equals("failed")) {
                                stopPolling();
                                handleError(j.optString("error","Download failed"));
                            } else {
                                handler.postDelayed(pollRunnable, 1500);
                            }
                        } catch (Exception e) { handleError(e.getMessage()); }
                    }
                    public void onError(String err) {
                        handler.postDelayed(pollRunnable, 3000);
                    }
                });
            }
        };
        handler.post(pollRunnable);
    }

    void saveVideoToPhone() {
        if (currentJobId == null) { toast("No video to save"); return; }
        String fname = prefs.getString("last_filename", "video.mp4");

        btnSaveToPhone.setEnabled(false);
        btnSaveToPhone.setText("Saving...");
        setStatus("Saving video to phone...", "#F9A825");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);

        FileDownloader.downloadToPhone(this,
                "/get-video/" + currentJobId, fname,
                new FileDownloader.DownloadCallback() {
                    public void onProgress(int pct) {
                        runOnUiThread(() -> {
                            progressBar.setProgress(pct);
                            tvPercent.setText(pct + "%");
                        });
                    }
                    public void onSuccess(String path) {
                        runOnUiThread(() -> {
                            progressBar.setProgress(100);
                            setStatus("✅ Saved to phone!\nLocation: " + path, "#4CAF50");
                            btnSaveToPhone.setText("✅ Saved!");
                            btnSaveToPhone.setEnabled(false);
                            toast("Video saved to: " + path);
                        });
                    }
                    public void onError(String err) {
                        runOnUiThread(() -> {
                            setStatus("Save failed: " + err, "#F44336");
                            btnSaveToPhone.setEnabled(true);
                            btnSaveToPhone.setText("💾 Save to Phone");
                        });
                    }
                });
    }

    void cancelDownload() {
        stopPolling();
        setStatus("Cancelled.", "#F44336");
        btnDownload.setEnabled(true);
        btnCancel.setEnabled(false);
    }

    void stopPolling() {
        isPollRunning = false;
        if (pollRunnable != null) handler.removeCallbacks(pollRunnable);
    }

    void handleError(String err) {
        stopPolling();
        runOnUiThread(() -> {
            setStatus("❌ " + err, "#F44336");
            btnDownload.setEnabled(true);
            btnCancel.setEnabled(false);
        });
    }

    void setStatus(String msg, String hex) {
        tvStatus.setText(msg);
        tvStatus.setTextColor(android.graphics.Color.parseColor(hex));
    }

    void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy() { super.onDestroy(); stopPolling(); }
}