package com.abdultool.activities;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.abdultool.R;
import com.abdultool.utils.FirebaseHelper;

public class LoginActivity extends AppCompatActivity {
    EditText etEmail, etPassword;
    Button btnLogin;
    TextView tvStatus, tvPlan;
    ProgressBar progressBar;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        prefs      = getSharedPreferences("AbdulTool", MODE_PRIVATE);
        etEmail    = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin   = findViewById(R.id.btnLogin);
        tvStatus   = findViewById(R.id.tvLoginStatus);
        tvPlan     = findViewById(R.id.tvPlanBadge);
        progressBar= findViewById(R.id.loginProgress);

        String plan = prefs.getString("license_plan", "trial").toUpperCase();
        tvPlan.setText(plan + " PLAN");

        String saved = prefs.getString("user_email", "");
        if (!saved.isEmpty()) etEmail.setText(saved);

        btnLogin.setOnClickListener(v -> doLogin());
    }

    void doLogin() {
        String email = etEmail.getText().toString().trim();
        String pass  = etPassword.getText().toString().trim();
        if (email.isEmpty() || pass.isEmpty()) {
            tvStatus.setText("Please enter email and password.");
            return;
        }
        setLoading(true);
        tvStatus.setText("Logging in...");

        FirebaseHelper.login(email, pass, (success, uid, message, idToken) ->
            runOnUiThread(() -> {
                setLoading(false);
                if (success) {
                    prefs.edit()
                        .putString("user_email", email)
                        .putString("user_uid", uid)
                        .putString("id_token", idToken)   // ← save token
                        .apply();
                    FirebaseHelper.getRole(uid, idToken, role -> runOnUiThread(() -> {
                        prefs.edit().putString("user_role", role).apply();
                        startActivity(new Intent(this, DashboardActivity.class));
                        finish();
                    }));
                } else {
                    tvStatus.setText(message);
                    tvStatus.setTextColor(getColor(R.color.colorError));
                }
            }));
    }

    void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
    }
}
