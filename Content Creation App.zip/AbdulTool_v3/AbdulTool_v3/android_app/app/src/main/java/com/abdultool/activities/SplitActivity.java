package com.abdultool.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.abdultool.R;
import com.abdultool.api.ApiClient;
import com.abdultool.utils.FileDownloader;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;

public class SplitActivity extends AppCompatActivity {

    SeekBar  seekDuration;
    TextView tvDurationLabel, tvStatus, tvJobInfo, tvClipsList;
    Button   btnSplit, btnPickVideo, btnUseDownloaded, btnSaveClips;
    ProgressBar progressBar;
    SharedPreferences prefs;

    Handler  handler = new Handler();
    Runnable pollRunnable;
    boolean  isPollRunning = false;

    private static final int REQ_PICK_VIDEO = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_split);

        prefs            = getSharedPreferences("AbdulTool", MODE_PRIVATE);
        seekDuration     = findViewById(R.id.seekDuration);
        tvDurationLabel  = findViewById(R.id.tvDurationLabel);
        tvStatus         = findViewById(R.id.tvSplitStatus);
        tvJobInfo        = findViewById(R.id.tvJobInfo);
        tvClipsList      = findViewById(R.id.tvClipsList);
        btnSplit         = findViewById(R.id.btnSplit);
        btnPickVideo     = findViewById(R.id.btnPickVideo);
        btnUseDownloaded = findViewById(R.id.btnUseDownloaded);
        btnSaveClips     = findViewById(R.id.btnSaveClips);
        progressBar      = findViewById(R.id.splitProgress);

        // Duration slider
        seekDuration.setMax(59);
        seekDuration.setProgress(3);
        tvDurationLabel.setText("Clip Duration: 4 seconds");
        seekDuration.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                tvDurationLabel.setText("Clip Duration: " + (p+1) + " seconds");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        String lastJobId = prefs.getString("last_job_id", "");
        String lastFile  = prefs.getString("last_filename", "");
        if (!lastJobId.isEmpty()) {
            tvJobInfo.setText("✅ Downloaded video ready:\n" + lastFile
                    + "\n\nUse it or pick a different video from device.");
            tvJobInfo.setTextColor(getColor(R.color.colorSuccess));
        } else {
            tvJobInfo.setText("No downloaded video.\nPick a video from your device storage.");
            tvJobInfo.setTextColor(getColor(R.color.colorTextMuted));
        }

        btnSplit.setEnabled(false);
        btnSaveClips.setVisibility(View.GONE);
        btnUseDownloaded.setEnabled(!lastJobId.isEmpty());

        btnPickVideo.setOnClickListener(v -> pickVideo());
        btnUseDownloaded.setOnClickListener(v -> useDownloadedVideo());
        btnSplit.setOnClickListener(v -> startSplit());
        btnSaveClips.setOnClickListener(v -> saveClipsToPhone());
    }

    void pickVideo() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("video/*");
        startActivityForResult(Intent.createChooser(i,"Select Video"), REQ_PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int req, int res, @Nullable Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK_VIDEO && res == Activity.RESULT_OK && data != null) {
            uploadVideoToServer(data.getData());
        }
    }

    void uploadVideoToServer(Uri uri) {
        setStatus("Preparing upload...", "#F9A825");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        btnPickVideo.setEnabled(false);
        btnSplit.setEnabled(false);

        new Thread(() -> {
            try {
                String filename = getFileName(uri);
                File   temp     = new File(getCacheDir(), filename);
                InputStream  is = getContentResolver().openInputStream(uri);
                FileOutputStream fos = new FileOutputStream(temp);
                byte[] buf = new byte[8192]; int len;
                while ((len = is.read(buf)) != -1) fos.write(buf,0,len);
                is.close(); fos.close();

                long sizeMb = temp.length()/1048576;
                runOnUiThread(() -> setStatus(
                        "Uploading " + filename + " (" + sizeMb + " MB)...", "#F9A825"));

                ApiClient.uploadVideo(temp, new okhttp3.Callback() {
                    public void onFailure(Call c, IOException e) {
                        runOnUiThread(() -> {
                            setStatus("Upload failed: " + e.getMessage(), "#F44336");
                            progressBar.setIndeterminate(false);
                            progressBar.setVisibility(View.GONE);
                            btnPickVideo.setEnabled(true);
                        });
                    }
                    public void onResponse(Call c, Response r) throws IOException {
                        try {
                            JSONObject json = new JSONObject(r.body().string());
                            String jobId = json.getString("job_id");
                            String fname = json.getString("filename");
                            double size  = json.optDouble("size_mb",0);
                            prefs.edit()
                                    .putString("split_job_id", jobId)
                                    .putString("face_filter_job_id", jobId)
                                    .putString("split_filename", fname)
                                    .apply();
                            runOnUiThread(() -> {
                                progressBar.setIndeterminate(false);
                                progressBar.setProgress(100);
                                tvJobInfo.setText("✅ Uploaded: " + fname
                                        + " (" + String.format("%.1f",size) + " MB)\nReady to split!");
                                tvJobInfo.setTextColor(getColor(R.color.colorSuccess));
                                setStatus("Upload complete! Now tap Split.", "#4CAF50");
                                btnPickVideo.setEnabled(true);
                                btnSplit.setEnabled(true);
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> setStatus("Error: " + e.getMessage(),"#F44336"));
                        }
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setStatus("Error: " + e.getMessage(), "#F44336");
                    btnPickVideo.setEnabled(true);
                    progressBar.setVisibility(View.GONE);
                });
            }
        }).start();
    }

    void useDownloadedVideo() {
        String jobId = prefs.getString("last_job_id","");
        String fname = prefs.getString("last_filename","");
        prefs.edit()
                .putString("split_job_id", jobId)
                .putString("face_filter_job_id", jobId)
                .apply();
        tvJobInfo.setText("✅ Using: " + fname + "\nReady to split!");
        tvJobInfo.setTextColor(getColor(R.color.colorSuccess));
        btnSplit.setEnabled(true);
        setStatus("Video selected. Choose duration and tap Split.", "#4CAF50");
    }

    void startSplit() {
        String jobId = prefs.getString("split_job_id","");
        if (jobId.isEmpty()) { toast("Select a video first"); return; }

        int secs = seekDuration.getProgress()+1;
        setStatus("Splitting into " + secs + "s clips...", "#F9A825");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(false);
        progressBar.setProgress(0);
        btnSplit.setEnabled(false);
        btnPickVideo.setEnabled(false);
        btnSaveClips.setVisibility(View.GONE);
        tvClipsList.setText("");

        try {
            JSONObject body = new JSONObject();
            body.put("job_id", jobId);
            body.put("clip_seconds", secs);
            ApiClient.post("/split", body, new ApiClient.ApiCallback() {
                public void onSuccess(String resp) {
                    try {
                        String splitJobId = new JSONObject(resp).getString("split_job_id");
                        startPolling(splitJobId, jobId);
                    } catch (Exception e) { handleError(e.getMessage()); }
                }
                public void onError(String err) { handleError(err); }
            });
        } catch (Exception e) { handleError(e.getMessage()); }
    }

    void startPolling(String splitJobId, String originalJobId) {
        isPollRunning = true;
        pollRunnable = new Runnable() {
            public void run() {
                if (!isPollRunning) return;
                ApiClient.get("/job/" + splitJobId, new ApiClient.ApiCallback() {
                    public void onSuccess(String resp) {
                        try {
                            JSONObject j  = new JSONObject(resp);
                            String status = j.optString("status","");
                            int pct       = (int) j.optDouble("percent",0);
                            runOnUiThread(() -> {
                                progressBar.setProgress(pct);
                                setStatus("Splitting... " + pct + "%", "#F9A825");
                            });

                            if (status.equals("done")) {
                                stopPolling();
                                int count      = j.optInt("count",0);
                                JSONArray clips = j.optJSONArray("clips");
                                StringBuilder sb = new StringBuilder();
                                sb.append("✅ ").append(count).append(" clips ready!\n\n");
                                if (clips != null) {
                                    int show = Math.min(clips.length(),8);
                                    for (int i=0; i<show; i++)
                                        sb.append("  📹 ").append(clips.getString(i)).append("\n");
                                    if (clips.length()>8)
                                        sb.append("  ...+").append(clips.length()-8).append(" more\n");
                                }
                                sb.append("\nTap 'Save Clips to Phone' to download all clips.");
                                runOnUiThread(() -> {
                                    progressBar.setProgress(100);
                                    setStatus("✅ Split complete!", "#4CAF50");
                                    tvClipsList.setText(sb.toString());
                                    btnSplit.setEnabled(true);
                                    btnPickVideo.setEnabled(true);
                                    btnSaveClips.setVisibility(View.VISIBLE);
                                    btnSaveClips.setText("💾 Save " + count + " Clips to Phone");
                                });
                            } else if (status.equals("failed")) {
                                stopPolling();
                                handleError(j.optString("error","Split failed"));
                            } else {
                                handler.postDelayed(pollRunnable, 1500);
                            }
                        } catch (Exception e) { handleError(e.getMessage()); }
                    }
                    public void onError(String err) { handler.postDelayed(pollRunnable,3000); }
                });
            }
        };
        handler.post(pollRunnable);
    }

    void saveClipsToPhone() {
        String jobId = prefs.getString("split_job_id","");
        if (jobId.isEmpty()) { toast("No clips to save"); return; }

        btnSaveClips.setEnabled(false);
        btnSaveClips.setText("Downloading ZIP...");
        setStatus("Downloading clips ZIP to phone...", "#F9A825");
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);

        String filename = "all_clips_" + jobId + ".zip";
        FileDownloader.downloadToPhone(this,
                "/get-clips/" + jobId, filename,
                new FileDownloader.DownloadCallback() {
                    public void onProgress(int pct) {
                        runOnUiThread(() -> progressBar.setProgress(pct));
                    }
                    public void onSuccess(String path) {
                        runOnUiThread(() -> {
                            progressBar.setProgress(100);
                            setStatus("✅ Clips saved!\nLocation: " + path
                                    + "\n\nExtract the ZIP to get individual MP4 clips.", "#4CAF50");
                            btnSaveClips.setText("✅ Saved to Phone!");
                            toast("Clips saved to: " + path);
                        });
                    }
                    public void onError(String err) {
                        runOnUiThread(() -> {
                            setStatus("Save failed: " + err, "#F44336");
                            btnSaveClips.setEnabled(true);
                            btnSaveClips.setText("💾 Save Clips to Phone");
                        });
                    }
                });
    }

    String getFileName(Uri uri) {
        String result = "video.mp4";
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if (c != null && c.moveToFirst()) result = c.getString(0);
        } catch (Exception ignored) {}
        return result;
    }

    void stopPolling() {
        isPollRunning = false;
        if (pollRunnable != null) handler.removeCallbacks(pollRunnable);
    }

    void handleError(String err) {
        stopPolling();
        runOnUiThread(() -> {
            setStatus("❌ " + err, "#F44336");
            progressBar.setVisibility(View.GONE);
            btnSplit.setEnabled(true);
            btnPickVideo.setEnabled(true);
        });
    }

    void setStatus(String msg, String hex) {
        tvStatus.setText(msg);
        tvStatus.setTextColor(android.graphics.Color.parseColor(hex));
    }

    void toast(String msg) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy() { super.onDestroy(); stopPolling(); }
}