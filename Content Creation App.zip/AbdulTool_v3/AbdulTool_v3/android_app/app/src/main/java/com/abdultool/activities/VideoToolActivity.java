package com.abdultool.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.abdultool.R;

public class VideoToolActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_tool);

        SharedPreferences prefs = getSharedPreferences("AbdulTool", MODE_PRIVATE);
        String plan = prefs.getString("license_plan", "trial").toUpperCase();
        String role = prefs.getString("user_role", "user");

        TextView tvPlan = findViewById(R.id.tvVideoToolPlan);
        tvPlan.setText(plan);

        // Section 1 — Download
        findViewById(R.id.cardDownload).setOnClickListener(v ->
            startActivity(new Intent(this, DownloadActivity.class)));

        // Section 2 — Split
        findViewById(R.id.cardSplit).setOnClickListener(v ->
            startActivity(new Intent(this, SplitActivity.class)));

        // Section 3 — Face Filter
        boolean faceUnlocked = !plan.equals("TRIAL") || role.equals("admin");
        findViewById(R.id.cardFaceFilter).setOnClickListener(v -> {
            if (faceUnlocked)
                startActivity(new Intent(this, FaceFilterActivity.class));
            else
                Toast.makeText(this, "Face Filter requires Pro or Lifetime plan", Toast.LENGTH_LONG).show();
        });

        TextView tvFaceLock = findViewById(R.id.tvFaceLock);
        tvFaceLock.setText(faceUnlocked ? "✅ Unlocked" : "🔒 Pro/Lifetime only");
        tvFaceLock.setTextColor(faceUnlocked
            ? getColor(R.color.colorSuccess) : getColor(R.color.colorError));
    }
}
