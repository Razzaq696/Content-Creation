package com.abdultool.api;

import okhttp3.*;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class ApiClient {

    // Trailing slash removed — all paths must start with "/"
    public static final String BASE_URL = "https://web-production-a3c88.up.railway.app";
    public static final String API_KEY  = "abdultool-secret-2024";

    private static final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(30,  TimeUnit.SECONDS)
            .readTimeout(300,    TimeUnit.SECONDS)
            .writeTimeout(300,   TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();

    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    // ── Callback interface ─────────────────────────────────────────────────
    public interface ApiCallback {
        void onSuccess(String response);
        void onError(String error);
    }

    // ── GET ────────────────────────────────────────────────────────────────
    public static void get(String path, ApiCallback cb) {
        Request req = new Request.Builder()
                .url(BASE_URL + path)
                .addHeader("X-API-Key", API_KEY)
                .build();
        client.newCall(req).enqueue(new Callback() {
            public void onFailure(Call c, IOException e) {
                cb.onError(e.getMessage() != null ? e.getMessage() : "Network error");
            }
            public void onResponse(Call c, Response r) throws IOException {
                String body = r.body() != null ? r.body().string() : "{}";
                if (r.isSuccessful()) cb.onSuccess(body);
                else cb.onError("HTTP " + r.code() + ": " + body);
            }
        });
    }

    // ── POST JSON ──────────────────────────────────────────────────────────
    public static void post(String path, JSONObject json, ApiCallback cb) {
        RequestBody body = RequestBody.create(json.toString(), JSON);
        Request req = new Request.Builder()
                .url(BASE_URL + path)
                .addHeader("X-API-Key", API_KEY)
                .post(body)
                .build();
        client.newCall(req).enqueue(new Callback() {
            public void onFailure(Call c, IOException e) {
                cb.onError(e.getMessage() != null ? e.getMessage() : "Network error");
            }
            public void onResponse(Call c, Response r) throws IOException {
                String body2 = r.body() != null ? r.body().string() : "{}";
                if (r.isSuccessful()) cb.onSuccess(body2);
                else cb.onError("HTTP " + r.code() + ": " + body2);
            }
        });
    }

    // ── POST multipart — upload video file ────────────────────────────────
    public static void uploadVideo(File videoFile, Callback callback) {
        String mime = videoFile.getName().endsWith(".mp4") ? "video/mp4" : "video/*";
        RequestBody fileBody = RequestBody.create(videoFile, MediaType.parse(mime));
        RequestBody multipart = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("video", videoFile.getName(), fileBody)
                .build();
        Request req = new Request.Builder()
                .url(BASE_URL + "/upload")
                .addHeader("X-API-Key", API_KEY)
                .post(multipart)
                .build();
        client.newCall(req).enqueue(callback);
    }

    // ── POST multipart — upload reference face image ───────────────────────
    public static void uploadRefFace(File imageFile, String jobId, ApiCallback cb) {
        String ext  = imageFile.getName().contains(".")
                ? imageFile.getName().substring(imageFile.getName().lastIndexOf("."))
                : ".jpg";
        String mime = ext.equalsIgnoreCase(".png") ? "image/png" : "image/jpeg";

        RequestBody fileBody = RequestBody.create(imageFile, MediaType.parse(mime));
        RequestBody multipart = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("image", "ref" + ext, fileBody)
                .addFormDataPart("job_id", jobId)
                .build();
        Request req = new Request.Builder()
                .url(BASE_URL + "/upload-ref-face")
                .addHeader("X-API-Key", API_KEY)
                .post(multipart)
                .build();
        client.newCall(req).enqueue(new Callback() {
            public void onFailure(Call c, IOException e) {
                cb.onError(e.getMessage() != null ? e.getMessage() : "Network error");
            }
            public void onResponse(Call c, Response r) throws IOException {
                String body = r.body() != null ? r.body().string() : "{}";
                if (r.isSuccessful()) cb.onSuccess(body);
                else cb.onError("HTTP " + r.code() + ": " + body);
            }
        });
    }
}
