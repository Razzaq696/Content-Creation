"""
Abdul Tool — Flask API Server v3.1
Fixes:
  - mediapipe 0.10+ new API (no solutions attribute)
  - /get-video, /get-clips, /get-matched endpoints
  - face-recognition for specific face matching
  - reference image upload
"""
from flask import Flask, request, jsonify, send_file
import os, threading, uuid, subprocess, shutil, zipfile, io

app = Flask(__name__)
JOBS         = {}
DOWNLOAD_DIR = "/tmp/downloads"
CLIPS_DIR    = "/tmp/clips"
UPLOAD_DIR   = "/tmp/uploads"
REF_DIR      = "/tmp/ref_faces"
os.makedirs(DOWNLOAD_DIR, exist_ok=True)
os.makedirs(CLIPS_DIR,    exist_ok=True)
os.makedirs(UPLOAD_DIR,   exist_ok=True)
os.makedirs(REF_DIR,      exist_ok=True)

API_KEY = os.environ.get("API_KEY", "abdultool-secret-2024")

def check_auth():
    return request.headers.get("X-API-Key", "") == API_KEY

def update_job(job_id, **kwargs):
    if job_id in JOBS:
        JOBS[job_id].update(kwargs)

# ── Health ─────────────────────────────────────────────────────────────────────
@app.route("/", methods=["GET"])
def health():
    try:
        r = subprocess.run(["ffmpeg", "-version"], capture_output=True, timeout=5)
        ffmpeg_ok = r.returncode == 0
    except Exception:
        ffmpeg_ok = False
    try:
        import yt_dlp
        ytdlp_ok = True
    except Exception:
        ytdlp_ok = False
    try:
        import mediapipe
        mp_ok = True
    except Exception:
        mp_ok = False
    return jsonify({"status": "ok", "ffmpeg": ffmpeg_ok,
                    "yt_dlp": ytdlp_ok, "mediapipe": mp_ok, "version": "3.1"})

# ── Download video (URL) ───────────────────────────────────────────────────────
@app.route("/download", methods=["POST"])
def download():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401
    data = request.get_json() or {}
    url  = data.get("url", "").strip()
    if not url:
        return jsonify({"error": "URL required"}), 400

    job_id = str(uuid.uuid4())[:8]
    JOBS[job_id] = {
        "status": "queued", "percent": 0,
        "downloaded_mb": 0, "total_mb": 0,
        "speed_kb": 0, "eta_sec": 0,
        "result": None, "filename": None,
        "size_mb": 0, "error": None
    }

    def _run():
        import yt_dlp
        out_tmpl = os.path.join(DOWNLOAD_DIR, f"{job_id}.%(ext)s")

        def _hook(d):
            if d.get("status") == "downloading":
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or 1
                dl    = d.get("downloaded_bytes", 0)
                update_job(job_id,
                    status        = "downloading",
                    percent       = round(dl / total * 100, 1),
                    downloaded_mb = round(dl / 1048576, 1),
                    total_mb      = round(total / 1048576, 1),
                    speed_kb      = round((d.get("speed") or 0) / 1024, 1),
                    eta_sec       = d.get("eta") or 0,
                )
            elif d.get("status") == "finished":
                update_job(job_id, status="processing", percent=99)

        format_attempts = [
            "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best[height<=720]/best",
            "18",
            "best",
        ]
        opts_base = {
            "outtmpl":        out_tmpl,
            "progress_hooks": [_hook],
            "noplaylist":     True,
            "quiet":          True,
            "no_warnings":    True,
            "socket_timeout": 30,
            "retries":        3,
            "extractor_args": {
                "youtube": {
                    "player_client": ["android_vr", "android", "web"],
                    "player_skip":   ["webpage", "configs"],
                }
            },
            "http_headers": {
                "User-Agent": (
                    "com.google.android.youtube/17.36.4 "
                    "(Linux; U; Android 12; GB) gzip"
                ),
            },
        }
        last_error = None
        for fmt in format_attempts:
            try:
                opts = {**opts_base, "format": fmt, "merge_output_format": "mp4"}
                with yt_dlp.YoutubeDL(opts) as ydl:
                    info  = ydl.extract_info(url, download=True)
                    fname = ydl.prepare_filename(info)
                    mp4   = os.path.splitext(fname)[0] + ".mp4"
                    path  = mp4 if os.path.exists(mp4) else fname
                    if os.path.exists(path):
                        size = os.path.getsize(path) / 1048576
                        update_job(job_id,
                            status="done", percent=100,
                            result=path, filename=os.path.basename(path),
                            size_mb=round(size, 1)
                        )
                        return
            except Exception as e:
                last_error = str(e)
                continue
        update_job(job_id, status="failed", error=last_error or "All download attempts failed")

    threading.Thread(target=_run, daemon=True).start()
    return jsonify({"job_id": job_id})

# ── Upload video from device ───────────────────────────────────────────────────
@app.route("/upload", methods=["POST"])
def upload_video():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401
    if "video" not in request.files:
        return jsonify({"error": "No video file in request"}), 400

    file   = request.files["video"]
    job_id = str(uuid.uuid4())[:8]
    save_path = os.path.join(UPLOAD_DIR, f"{job_id}_{file.filename}")
    file.save(save_path)
    size_mb = os.path.getsize(save_path) / 1048576
    JOBS[job_id] = {
        "status":   "done",
        "percent":  100,
        "result":   save_path,
        "filename": file.filename,
        "size_mb":  round(size_mb, 1),
        "error":    None,
    }
    return jsonify({
        "job_id":   job_id,
        "filename": file.filename,
        "size_mb":  round(size_mb, 1),
        "message":  "Video uploaded successfully"
    })

# ── Upload reference face image ────────────────────────────────────────────────
@app.route("/upload-ref-face", methods=["POST"])
def upload_ref_face():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401
    if "image" not in request.files:
        return jsonify({"error": "No image file. Use field name: image"}), 400

    file     = request.files["image"]
    job_id   = request.form.get("job_id", "")
    if not job_id:
        return jsonify({"error": "job_id required"}), 400

    ext      = os.path.splitext(file.filename)[1] or ".jpg"
    ref_path = os.path.join(REF_DIR, f"{job_id}_ref{ext}")
    file.save(ref_path)

    # Verify face is detectable in reference image
    try:
        import face_recognition
        img = face_recognition.load_image_file(ref_path)
        encs = face_recognition.face_encodings(img)
        if len(encs) == 0:
            os.remove(ref_path)
            return jsonify({"error": "No face detected in reference image. Use a clear frontal photo."}), 400
        return jsonify({"success": True, "message": "Reference face saved!", "ref_path": ref_path})
    except ImportError:
        # face_recognition not installed fallback — accept image, use mediapipe similarity
        return jsonify({"success": True, "message": "Reference image saved (basic mode).", "ref_path": ref_path})

# ── Job status ─────────────────────────────────────────────────────────────────
@app.route("/job/<job_id>", methods=["GET"])
def job_status(job_id):
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401
    job = JOBS.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(job)

# ── Split video ────────────────────────────────────────────────────────────────
@app.route("/split", methods=["POST"])
def split():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data      = request.get_json() or {}
    job_id    = data.get("job_id", "")
    clip_secs = int(data.get("clip_seconds", 4))

    job = JOBS.get(job_id)
    if not job or job.get("status") != "done":
        return jsonify({"error": "Video not ready. Download or upload first."}), 400

    video_path = job.get("result")
    if not video_path or not os.path.exists(video_path):
        return jsonify({"error": "Video file not found on server."}), 400

    split_job_id = f"{job_id}_split"
    JOBS[split_job_id] = {
        "status": "processing", "percent": 0,
        "clips": [], "count": 0, "error": None
    }

    def _split():
        try:
            out_dir = os.path.join(CLIPS_DIR, job_id)
            os.makedirs(out_dir, exist_ok=True)
            ff = shutil.which("ffmpeg") or "ffmpeg"

            probe = subprocess.run([ff, "-i", video_path], capture_output=True, text=True)
            duration = 0
            for line in probe.stderr.split("\n"):
                if "Duration:" in line:
                    try:
                        t = line.split("Duration:")[1].split(",")[0].strip()
                        h, m, s = t.split(":")
                        duration = int(h)*3600 + int(m)*60 + float(s)
                    except Exception:
                        pass

            cmd = [
                ff, "-i", video_path,
                "-c", "copy", "-map", "0",
                "-segment_time", str(clip_secs),
                "-f", "segment", "-reset_timestamps", "1", "-y",
                os.path.join(out_dir, "clip_%04d.mp4")
            ]
            process = subprocess.Popen(cmd, stderr=subprocess.PIPE,
                                       stdout=subprocess.PIPE, text=True)
            for line in process.stderr:
                if "time=" in line and duration > 0:
                    try:
                        t_str = line.split("time=")[1].split(" ")[0].strip()
                        h, m, s = t_str.split(":")
                        cur = int(h)*3600 + int(m)*60 + float(s)
                        pct = min(round(cur / duration * 100, 1), 99)
                        update_job(split_job_id, percent=pct)
                    except Exception:
                        pass
            process.wait()
            if process.returncode != 0:
                raise Exception(f"ffmpeg failed with code {process.returncode}")

            clips = sorted([f for f in os.listdir(out_dir) if f.endswith(".mp4")])
            update_job(split_job_id, status="done", percent=100,
                       clips=clips, count=len(clips), job_dir=job_id)
        except Exception as e:
            update_job(split_job_id, status="failed", error=str(e))

    threading.Thread(target=_split, daemon=True).start()
    return jsonify({"split_job_id": split_job_id})

# ── Face filter ────────────────────────────────────────────────────────────────
@app.route("/face-filter", methods=["POST"])
def face_filter():
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    data        = request.get_json() or {}
    job_id      = data.get("job_id", "")
    filter_type = data.get("filter_type", "any")   # "any" or "specific"
    clip_dir    = os.path.join(CLIPS_DIR, job_id)

    if not os.path.exists(clip_dir):
        return jsonify({"error": "No clips found. Run split first."}), 400

    filter_job_id = f"{job_id}_filter"
    JOBS[filter_job_id] = {
        "status": "processing", "percent": 0,
        "matched": [], "total": 0, "count": 0, "error": None
    }

    def _filter():
        try:
            # ── mediapipe 0.10+ new API ──────────────────────────────────────
            import mediapipe as mp
            import cv2

            # NEW API: use mp.tasks or direct class — no mp.solutions
            try:
                # mediapipe 0.10+ way
                from mediapipe.tasks import python as mp_python
                from mediapipe.tasks.python import vision as mp_vision
                base_opts = mp_python.BaseOptions(
                    model_asset_path=_get_face_detector_model())
                options = mp_vision.FaceDetectorOptions(
                    base_options=base_opts,
                    min_detection_confidence=0.5)
                detector = mp_vision.FaceDetector.create_from_options(options)
                use_tasks_api = True
            except Exception:
                # Fallback: try legacy solutions API
                try:
                    face_detection = mp.solutions.face_detection.FaceDetection(
                        model_selection=0, min_detection_confidence=0.5)
                    use_tasks_api = False
                    detector = face_detection
                except Exception:
                    # Last resort: use OpenCV DNN face detector
                    detector = _get_opencv_face_detector()
                    use_tasks_api = "opencv"

            # ── Load reference face encoding if specific mode ─────────────────
            ref_encoding = None
            if filter_type == "specific":
                ref_files = [f for f in os.listdir(REF_DIR)
                             if f.startswith(job_id + "_ref")]
                if ref_files:
                    try:
                        import face_recognition
                        ref_img = face_recognition.load_image_file(
                            os.path.join(REF_DIR, ref_files[0]))
                        encs = face_recognition.face_encodings(ref_img)
                        if encs:
                            ref_encoding = encs[0]
                    except ImportError:
                        pass  # fall back to any-face if lib not available

            clips   = sorted([f for f in os.listdir(clip_dir) if f.endswith(".mp4")])
            matched = []
            total   = len(clips)
            update_job(filter_job_id, total=total)

            for i, clip in enumerate(clips):
                clip_path = os.path.join(clip_dir, clip)
                cap   = cv2.VideoCapture(clip_path)
                found = False
                fc    = 0

                while cap.isOpened() and not found:
                    ret, frame = cap.read()
                    if not ret:
                        break
                    if fc % 10 == 0:  # check every 10th frame
                        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                        if use_tasks_api == True:
                            # mediapipe tasks API
                            mp_image = mp.Image(
                                image_format=mp.ImageFormat.SRGB, data=rgb)
                            result = detector.detect(mp_image)
                            has_face = len(result.detections) > 0
                        elif use_tasks_api == False:
                            # legacy solutions API
                            res = detector.process(rgb)
                            has_face = res.detections is not None and len(res.detections) > 0
                        else:
                            # opencv fallback
                            has_face = _opencv_detect_face(detector, frame)

                        if has_face:
                            if filter_type == "specific" and ref_encoding is not None:
                                try:
                                    import face_recognition
                                    unknown = face_recognition.face_encodings(rgb)
                                    if unknown:
                                        matches = face_recognition.compare_faces(
                                            [ref_encoding], unknown[0], tolerance=0.55)
                                        found = bool(matches[0])
                                    else:
                                        found = False
                                except ImportError:
                                    found = True  # fallback: match any face
                            else:
                                found = True
                    fc += 1

                cap.release()
                if found:
                    matched.append(clip)

                pct = round((i + 1) / total * 100, 1)
                update_job(filter_job_id, percent=pct, matched=matched, count=len(matched))

            # Clean up detector
            try:
                if use_tasks_api == False:
                    detector.close()
                elif use_tasks_api == True:
                    detector.close()
            except Exception:
                pass

            update_job(filter_job_id, status="done", percent=100,
                       matched=matched, count=len(matched), total=total,
                       job_id=job_id)

        except Exception as e:
            import traceback
            update_job(filter_job_id, status="failed",
                       error=str(e) + "\n" + traceback.format_exc())

    threading.Thread(target=_filter, daemon=True).start()
    return jsonify({"filter_job_id": filter_job_id})


def _get_face_detector_model():
    """Download mediapipe face detector tflite model if not cached."""
    model_path = "/tmp/blaze_face_short_range.tflite"
    if not os.path.exists(model_path):
        import urllib.request
        url = ("https://storage.googleapis.com/mediapipe-models/"
               "face_detector/blaze_face_short_range/float16/1/"
               "blaze_face_short_range.tflite")
        urllib.request.urlretrieve(url, model_path)
    return model_path


def _get_opencv_face_detector():
    """OpenCV DNN Haar fallback detector."""
    cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    return cv2.CascadeClassifier(cascade_path)


def _opencv_detect_face(classifier, frame):
    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = classifier.detectMultiScale(gray, scaleFactor=1.1,
                                        minNeighbors=5, minSize=(30, 30))
    return len(faces) > 0


# ── Serve video file ───────────────────────────────────────────────────────────
@app.route("/get-video/<job_id>", methods=["GET"])
def get_video(job_id):
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401
    job = JOBS.get(job_id)
    if not job or not job.get("result"):
        return jsonify({"error": "Video not found"}), 404
    path = job["result"]
    if not os.path.exists(path):
        return jsonify({"error": "File not found on disk"}), 404
    return send_file(path, as_attachment=True,
                     download_name=job.get("filename", "video.mp4"),
                     mimetype="video/mp4")


# ── Serve all clips as ZIP ─────────────────────────────────────────────────────
@app.route("/get-clips/<job_id>", methods=["GET"])
def get_clips(job_id):
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401
    clip_dir = os.path.join(CLIPS_DIR, job_id)
    if not os.path.exists(clip_dir):
        return jsonify({"error": "No clips found"}), 404

    clips = sorted([f for f in os.listdir(clip_dir) if f.endswith(".mp4")])
    if not clips:
        return jsonify({"error": "No clips in directory"}), 404

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for clip in clips:
            zf.write(os.path.join(clip_dir, clip), clip)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"all_clips_{job_id}.zip",
                     mimetype="application/zip")


# ── Serve matched clips as ZIP ─────────────────────────────────────────────────
@app.route("/get-matched/<job_id>", methods=["GET"])
def get_matched(job_id):
    if not check_auth():
        return jsonify({"error": "Unauthorized"}), 401

    filter_job_id = f"{job_id}_filter"
    job = JOBS.get(filter_job_id)
    if not job or job.get("status") != "done":
        return jsonify({"error": "Filter not done yet"}), 400

    matched  = job.get("matched", [])
    clip_dir = os.path.join(CLIPS_DIR, job_id)

    if not matched:
        return jsonify({"error": "No matched clips"}), 404

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for clip in matched:
            path = os.path.join(clip_dir, clip)
            if os.path.exists(path):
                zf.write(path, clip)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"matched_{job_id}.zip",
                     mimetype="application/zip")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
